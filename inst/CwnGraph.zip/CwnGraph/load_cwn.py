import pickle
from CwnGraph import CwnBase, CwnAnnotator
from CwnGraph import CwnRelationType
# 似乎可以不用 run 
cwn = CwnBase.install_cwn("data/cwn_graph.pyobj")
cwn = CwnBase()
#from pprint import pprint

